# -*- coding: utf-8 -*-
"""
realtime.py — 温度补偿型压力测量（中心波长 + FPI 周期）
- 实时计算：FBG 中心波长 & FPI 周期
- 标定：同时记录 λ0 和 T0；之后显示 压力(N) 与 温度(°C) 随时间
- 上图：光谱（仅画中心竖线，不画 FPI 处理曲线）
- 中图：中心/压力 vs 时间（根据是否已标定自动切换）
- 下图：FPI 周期 / 温度 vs 时间（根据是否已标定自动切换）
"""

from PyQt5.QtCore import Qt, QObject, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QGroupBox, QCheckBox, QSizePolicy
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavToolbar
from matplotlib.figure import Figure
from matplotlib import rcParams

import numpy as np
import time

from scipy.signal import savgol_filter, find_peaks
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import curve_fit

# —— 中文显示 —— #
rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
rcParams['axes.unicode_minus'] = False

# 传感器灵敏度（单位统一为 nm）
K_P_NM_PER_N = 0.08349   # FBG 压力灵敏度（83.49 pm/N）
K_T_NM_PER_C = 0.01416   # FBG 温度灵敏度（14.16 pm/°C）
S_T_NM_PER_C = -0.17768  # FPI 温度灵敏度（-0.17768 nm/°C）

HISTORY_LEN = 1200
NUM_CHANNELS = 4

# FPI 目标周期范围（nm）
FPI_MIN_PERIOD = 5.0
FPI_MAX_PERIOD = 15.0


# ============================  设备采集线程  ==============================
class _ScanWorker(QObject):
    frameReady = pyqtSignal(object, object)
    finished   = pyqtSignal()
    def __init__(self, reader, wl_range):
        super().__init__()
        self.reader = reader
        self.wl_range = wl_range
        self._running = False

    def start(self):
        if self._running:
            return
        self._running = True
        try:
            self.reader.ensure_scan_params()
        except Exception:
            pass
        try:
            self.reader.start_spectrum_scan()
        except Exception:
            pass

        while self._running:
            try:
                wl, sp = self.reader.read_spectrum()
                try:
                    self.reader.start_spectrum_scan()
                except Exception:
                    pass
                self.frameReady.emit(wl, sp)
            except Exception:
                self.frameReady.emit([], [])
        self.finished.emit()

    def stop(self):
        self._running = False


# =============================  主窗口  ==================================
class RealTimeDecodeWindow(QMainWindow):
    def __init__(self, reader, wl_range, interval_ms=320):
        super().__init__()
        self.reader = reader
        self.wl_min, self.wl_max = wl_range

        # UI 刷新节流
        self.interval_ms = max(150, int(interval_ms))
        self._last_ui_update = 0.0

        # 线程对象
        self._th = None
        self._worker = None

        # 状态
        self.running = False
        self.realtime_enabled = False  # “实时计算”开关
        self.calibrated = False        # 是否已标定

        # 基线（标定时记录）
        self.baseline_center_nm = None   # λ0
        self.baseline_fpi_nm    = None   # T0

        # 实时值
        self.current_center = np.nan
        self.current_fpi    = np.nan
        self.current_tempC  = np.nan
        self.current_pressN = np.nan

        # 通道
        self.chan_enabled = [True, True, False, False]
        self.ref_ch = 0  # 参考通道（第一个勾选）

        # 曲线数据
        self.t0_center = None
        self.center_times = []      # s（或压力的时间）
        self.centers = []           # nm
        self.pressures = []         # N

        self.t0_fpi = None
        self.fpi_times = []         # s
        self.fpi_periods = []       # nm（未标定时）
        self.temps = []             # °C（标定后）

        # UI
        self._build_ui()
        self._init_plots()

        self.setWindowTitle("实时解读（温度补偿压力测量）")
        self.resize(1120, 930)
        self.setWindowFlags(self.windowFlags() | Qt.Window)

    # ------------------ UI ------------------
    def _build_ui(self):
        cw = QWidget(); self.setCentralWidget(cw)
        root = QVBoxLayout(cw); root.setContentsMargins(12, 12, 12, 12); root.setSpacing(10)

        # 控制区
        box = QGroupBox("控制"); hl = QHBoxLayout(box)
        self.btn_start = QPushButton("开启实时读取")
        self.btn_stop  = QPushButton("停止"); self.btn_stop.setEnabled(False)

        self.chk = [QCheckBox(f"通道{i+1}") for i in range(NUM_CHANNELS)]
        for i, c in enumerate(self.chk):
            c.setChecked(self.chan_enabled[i])
            c.stateChanged.connect(self._on_chan_toggle)

        self.chk_rt   = QCheckBox("实时计算")   # 同时计算中心+FPI
        self.chk_rt.stateChanged.connect(self._toggle_realtime)

        self.btn_calib = QPushButton("标定")
        self.btn_calib.clicked.connect(self._calibrate)

        self.lbl_center_now = QLabel("中心：-- nm")
        self.lbl_fpi_now    = QLabel("FPI周期：-- nm")
        self.lbl_temp_now   = QLabel("温度Δ：-- °C")
        self.lbl_press_now  = QLabel("压力：-- N")
        self.lbl_status     = QLabel("未开始")
        self.lbl_range      = QLabel(f"波长范围：{self.wl_min:.3f} — {self.wl_max:.3f} nm")

        self.btn_start.clicked.connect(self.start)
        self.btn_stop.clicked.connect(self.stop)

        hl.addWidget(self.btn_start); hl.addWidget(self.btn_stop); hl.addSpacing(8)
        for c in self.chk: hl.addWidget(c)
        hl.addSpacing(8)
        hl.addWidget(self.chk_rt); hl.addWidget(self.btn_calib)
        hl.addStretch(1)
        hl.addWidget(self.lbl_center_now); hl.addSpacing(10)
        hl.addWidget(self.lbl_fpi_now);    hl.addSpacing(10)
        hl.addWidget(self.lbl_temp_now);   hl.addSpacing(10)
        hl.addWidget(self.lbl_press_now);  hl.addSpacing(10)
        hl.addWidget(self.lbl_status);     hl.addSpacing(10); hl.addWidget(self.lbl_range)
        root.addWidget(box)

        # 图形（三行）
        self.fig = Figure(figsize=(10, 9), constrained_layout=True)
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.toolbar = NavToolbar(self.canvas, self)
        root.addWidget(self.toolbar); root.addWidget(self.canvas, 1)

    def _style_axes(self, ax):
        ax.grid(True, linestyle="--", linewidth=0.6, alpha=0.4)
        ax.set_facecolor("#FFFFFF")
        ax.spines['top'].set_alpha(0.25)
        ax.spines['right'].set_alpha(0.25)

    def _init_plots(self):
        # 上：实时光谱
        self.ax_spec = self.fig.add_subplot(3, 1, 1)
        self._style_axes(self.ax_spec)
        self.ax_spec.set_title("实时光谱")
        self.ax_spec.set_xlabel("波长 (nm)")
        self.ax_spec.set_ylabel("幅值")

        # 中：中心/压力 vs 时间
        self.ax_center = self.fig.add_subplot(3, 1, 2)
        self._style_axes(self.ax_center)
        self._set_center_titles()

        # 下：FPI 周期 / 温度 vs 时间
        self.ax_fpi = self.fig.add_subplot(3, 1, 3)
        self._style_axes(self.ax_fpi)
        self._set_fpi_titles()

        colors = ['tab:blue', 'tab:green', 'tab:red', 'tab:orange']
        labels = [f"通道 {i+1}" for i in range(NUM_CHANNELS)]
        self.lines = []
        for i in range(NUM_CHANNELS):
            (ln,) = self.ax_spec.plot([], [], color=colors[i], lw=1.4, label=labels[i])
            self.lines.append(ln)
        self.center_vline = self.ax_spec.axvline(0, color='m', ls='--', lw=1.4, alpha=0.85, label='中心')
        self.center_vline.set_visible(False)
        self.ax_spec.legend(loc="best", frameon=False)

        # 中图曲线（单通道）
        (self.line_center,) = self.ax_center.plot([], [], 'k-', lw=1.8, marker='o', markersize=3)
        # 下图曲线
        (self.line_fpi,) = self.ax_fpi.plot([], [], 'k-', lw=1.8, marker='o', markersize=3)

        self.canvas.draw_idle()

    def _set_center_titles(self):
        if not self.calibrated:
            self.ax_center.set_title("中心波长 vs 时间")
            self.ax_center.set_xlabel("时间 (s)")
            self.ax_center.set_ylabel("中心波长 (nm)")
        else:
            self.ax_center.set_title("压力 vs 时间")
            self.ax_center.set_xlabel("时间 (s)")
            self.ax_center.set_ylabel("压力 (N)")

    def _set_fpi_titles(self):
        if not self.calibrated:
            self.ax_fpi.set_title("FPI 周期 vs 时间")
            self.ax_fpi.set_xlabel("时间 (s)")
            self.ax_fpi.set_ylabel("周期 (nm)")
        else:
            self.ax_fpi.set_title("温度 vs 时间")
            self.ax_fpi.set_xlabel("时间 (s)")
            self.ax_fpi.set_ylabel("温度 (°C)")

    # ---------------- 控件回调 ----------------
    def _on_chan_toggle(self):
        for i, c in enumerate(self.chk):
            self.chan_enabled[i] = c.isChecked()
        self.ref_ch = next((i for i in range(NUM_CHANNELS) if self.chan_enabled[i]), 0)

    def _toggle_realtime(self):
        self.realtime_enabled = self.chk_rt.isChecked()
        self._reset_series_all()
        self._set_center_titles(); self._set_fpi_titles()
        self.canvas.draw_idle()

    def _calibrate(self):
        """标定：同时记录 λ0、T0；之后显示 压力 与 温度"""
        if not (np.isfinite(self.current_center) and np.isfinite(self.current_fpi)):
            self.lbl_status.setText("等待有效中心/FPI…")
            return
        self.baseline_center_nm = float(self.current_center)
        self.baseline_fpi_nm    = float(self.current_fpi)
        self.calibrated = True
        self._reset_series_all()
        self._set_center_titles(); self._set_fpi_titles()
        self.lbl_status.setText("已标定（温度补偿压力测量）")

    def _reset_series_center(self):
        self.t0_center = time.time()
        self.center_times.clear(); self.centers.clear(); self.pressures.clear()
        self.line_center.set_data([], [])

    def _reset_series_fpi(self):
        self.t0_fpi = time.time()
        self.fpi_times.clear(); self.fpi_periods.clear(); self.temps.clear()
        self.line_fpi.set_data([], [])

    def _reset_series_all(self):
        self._reset_series_center()
        self._reset_series_fpi()

    # ---------------- 启停 & 线程 ----------------
    def start(self):
        if self.running: return
        self.running = True
        self.btn_start.setEnabled(False); self.btn_stop.setEnabled(True)
        self.lbl_status.setText("运行中…")

        self._th = QThread(self)
        self._worker = _ScanWorker(self.reader, (self.wl_min, self.wl_max))
        self._worker.moveToThread(self._th)
        self._th.started.connect(self._worker.start)
        self._worker.frameReady.connect(self._on_frame)
        self._worker.finished.connect(self._th.quit)
        self._th.start()

    def stop(self):
        if not self.running: return
        self.running = False
        self.btn_start.setEnabled(True); self.btn_stop.setEnabled(False)
        self.lbl_status.setText("已停止")
        if self._worker: self._worker.stop()
        if self._th:
            self._th.quit(); self._th.wait()
        self._th = None; self._worker = None

    def closeEvent(self, e):
        self.stop(); super().closeEvent(e)

    # ---------------- 帧回调（主线程） ----------------
    def _on_frame(self, wavelengths, spectra):
        draw_now = (time.time() - self._last_ui_update) * 1000.0 >= self.interval_ms
        self._process_frame(wavelengths, spectra, do_draw=draw_now)
        if draw_now: self._last_ui_update = time.time()

    def _process_frame(self, wavelengths, spectra, do_draw: bool):
        if not wavelengths or not spectra or not any(len(ch) for ch in spectra):
            if do_draw: self.canvas.draw_idle()
            return

        w_full = np.asarray(wavelengths, float)
        mask = (w_full >= self.wl_min) & (w_full <= self.wl_max)
        if not np.any(mask): return
        wl = w_full[mask]

        # 上图：绘制所有勾选通道
        y_for_scale = []; ref = None
        for i in range(NUM_CHANNELS):
            if i >= len(spectra) or not spectra[i] or not self.chan_enabled[i]:
                self.lines[i].set_data([], []); continue
            y_all = np.asarray(spectra[i], float)
            if y_all.size != w_full.size:
                self.lines[i].set_data([], []); continue
            yy = y_all[mask]
            self.lines[i].set_data(wl, yy)
            y_for_scale.append(yy)
            if ref is None: ref = yy  # 参考通道

        if wl.size >= 2:
            xmin, xmax = float(wl.min()), float(wl.max()); span = max(xmax - xmin, 1e-9)
            self.ax_spec.set_xlim(xmin - 0.02*span, xmax + 0.02*span)
        if y_for_scale:
            ya = np.concatenate(y_for_scale); ymin, ymax = float(np.min(ya)), float(np.max(ya))
            yspan = max(ymax - ymin, 1e-9); self.ax_spec.set_ylim(ymin - 0.06*yspan, ymax + 0.06*yspan)

        # ===== 实时计算：中心 + FPI =====
        self.center_vline.set_visible(False)
        self.current_center = np.nan
        self.current_fpi    = np.nan
        self.current_tempC  = np.nan
        self.current_pressN = np.nan

        if self.realtime_enabled and ref is not None:
            # ---- FPI 周期（先算温度用） ----
            T = self._fpi_period_via_acf(wl, ref)
            if T is not None and np.isfinite(T):
                self.current_fpi = float(T)
                self.lbl_fpi_now.setText(f"FPI周期：{T:.4f} nm")

                tf = time.time(); self.t0_fpi = self.t0_fpi or tf
                tf_sec = tf - self.t0_fpi

                if not self.calibrated:
                    # 标定前：记录周期
                    self.fpi_times.append(tf_sec); self.fpi_periods.append(self.current_fpi)
                    self.fpi_times = self.fpi_times[-HISTORY_LEN:]
                    self.fpi_periods = self.fpi_periods[-HISTORY_LEN:]
                    self.line_fpi.set_data(self.fpi_times, self.fpi_periods)
                    if len(self.fpi_times) >= 2:
                        self.ax_fpi.set_xlim(self.fpi_times[0], self.fpi_times[-1] + 0.5)
                    pv = np.asarray(self.fpi_periods, float); pv = pv[np.isfinite(pv)]
                    if pv.size >= 2:
                        lo, hi = float(pv.min()), float(pv.max()); span = max(hi - lo, 1e-9)
                        self.ax_fpi.set_ylim(lo - 0.08*span, hi + 0.08*span)
                else:
                    # 标定后：周期 -> 温度
                    if self.baseline_fpi_nm is not None and S_T_NM_PER_C != 0:
                        dT = (self.current_fpi - self.baseline_fpi_nm) / S_T_NM_PER_C
                        self.current_tempC = float(dT)
                        self.lbl_temp_now.setText(f"温度Δ：{dT:+.3f} °C")
                        self.fpi_times.append(tf_sec); self.temps.append(dT)
                        self.fpi_times = self.fpi_times[-HISTORY_LEN:]
                        self.temps = self.temps[-HISTORY_LEN:]
                        self.line_fpi.set_data(self.fpi_times, self.temps)
                        if len(self.fpi_times) >= 2:
                            self.ax_fpi.set_xlim(self.fpi_times[0], self.fpi_times[-1] + 0.5)
                        tv = np.asarray(self.temps, float); tv = tv[np.isfinite(tv)]
                        if tv.size >= 2:
                            lo, hi = float(tv.min()), float(tv.max()); span = max(hi - lo, 1e-9)
                            self.ax_fpi.set_ylim(lo - 0.08*span, hi + 0.08*span)

            # ---- FBG 中心 ----
            c = self._center_gaussian_via_bandwidth(wl, ref)
            if c is not None and np.isfinite(c):
                self.current_center = float(c)
                self.center_vline.set_xdata([c, c]); self.center_vline.set_visible(True)
                self.lbl_center_now.setText(f"中心：{c:.4f} nm")

                t = time.time(); self.t0_center = self.t0_center or t
                tsec = t - self.t0_center

                if not self.calibrated:
                    self.center_times.append(tsec); self.centers.append(self.current_center)
                    self.center_times = self.center_times[-HISTORY_LEN:]
                    self.centers = self.centers[-HISTORY_LEN:]
                    self.line_center.set_data(self.center_times, self.centers)
                    if len(self.center_times) >= 2:
                        self.ax_center.set_xlim(self.center_times[0], self.center_times[-1] + 0.5)
                    vv = np.asarray(self.centers, float); vv = vv[np.isfinite(vv)]
                    if vv.size >= 2:
                        lo, hi = float(vv.min()), float(vv.max()); span = max(hi - lo, 1e-9)
                        self.ax_center.set_ylim(lo - 0.08*span, hi + 0.08*span)
                else:
                    # 标定后：温度补偿压力
                    if self.baseline_center_nm is not None:
                        d_lambda = self.current_center - self.baseline_center_nm
                        # 若当帧没有温度，临时按 0 处理（可改成最近一次 dT）
                        dT = self.current_tempC if np.isfinite(self.current_tempC) else 0.0
                        pressureN = (d_lambda - K_T_NM_PER_C * dT) / K_P_NM_PER_N
                        self.current_pressN = float(pressureN)
                        self.lbl_press_now.setText(f"压力：{pressureN:+.3f} N")

                        self.center_times.append(tsec); self.pressures.append(pressureN)
                        self.center_times = self.center_times[-HISTORY_LEN:]
                        self.pressures = self.pressures[-HISTORY_LEN:]
                        self.line_center.set_data(self.center_times, self.pressures)
                        if len(self.center_times) >= 2:
                            self.ax_center.set_xlim(self.center_times[0], self.center_times[-1] + 0.5)
                        pv = np.asarray(self.pressures, float); pv = pv[np.isfinite(pv)]
                        if pv.size >= 2:
                            lo, hi = float(pv.min()), float(pv.max()); span = max(hi - lo, 1e-9)
                            self.ax_center.set_ylim(lo - 0.08*span, hi + 0.08*span)

        if do_draw: self.canvas.draw_idle()

    # ---------------- 中心波长算法（半高宽 + 高斯拟合） ----------------
    def _denoise(self, y: np.ndarray) -> np.ndarray:
        n = y.size
        if n < 7: return y.copy()
        win = min(11, n - 1); 
        if win % 2 == 0: win -= 1
        y1 = savgol_filter(y, win, 2, mode='interp')
        return gaussian_filter1d(y1, sigma=1.0)

    def _half_points(self, wl, y, idx, peak_h, baseline):
        half = (peak_h - baseline)/2.0 + baseline
        i = idx
        while i > 0 and y[i] > half: i -= 1
        if i < idx and y[i] <= half:
            x1,y1 = wl[i], y[i]; x2,y2 = wl[i+1], y[i+1]
            left  = x1 + (half - y1) * (x2 - x1) / (y2 - y1) if y2 != y1 else x1
        else:
            left = wl[idx] - 0.15
        j = idx; n = len(y)-1
        while j < n and y[j] > half: j += 1
        if j > idx and y[j] <= half:
            x1,y1 = wl[j-1], y[j-1]; x2,y2 = wl[j], y[j]
            right = x1 + (half - y1) * (x2 - x1) / (y2 - y1) if y2 != y1 else x2
        else:
            right = wl[idx] + 0.15
        return left, right

    def _center_gaussian_via_bandwidth(self, wl: np.ndarray, y: np.ndarray):
        if wl.size < 16 or y.size != wl.size: return None
        y1 = self._denoise(y)
        baseline = np.percentile(y1, 5)
        adj = y1 - baseline
        peaks, props = find_peaks(adj, distance=20, prominence=0.08, height=0.02, width=2)
        if peaks.size == 0: return None
        idx = peaks[np.argmax(props['prominences'])]
        peak_wl = wl[idx]; peak_h = y1[idx]
        left, right = self._half_points(wl, y1, idx, peak_h, baseline)
        bw = max(1e-4, right - left)
        fit_mask = (wl >= peak_wl - bw) & (wl <= peak_wl + bw)
        x = wl[fit_mask]; z = y1[fit_mask]
        if x.size < 6: return float(peak_wl)
        try:
            def g(xx, a, x0, s, b): return a * np.exp(-(xx - x0)**2 / (2 * s**2)) + b
            s0 = max(0.005, bw / 2.3548); p0 = [max(0.1, peak_h - baseline), peak_wl, s0, baseline]
            popt, _ = curve_fit(g, x, z, p0=p0,
                                bounds=([0, x.min(), 1e-4, -np.inf], [np.inf, x.max(), 1.0, np.inf]),
                                maxfev=5000)
            x0 = float(popt[1])
            return x0 if (x.min() <= x0 <= x.max()) else float(peak_wl)
        except Exception:
            return float(peak_wl)

    # ---------------- FPI 周期算法（自相关 + 掩蔽带宽） ----------------
    def _hampel(self, x, k=9, t0=3.0):
        x = np.asarray(x, float); n = x.size
        y = x.copy(); k = int(max(3, k))
        for i in range(n):
            i1 = max(0, i-k); i2 = min(n, i+k+1)
            med = np.median(x[i1:i2])
            mad = 1.4826*np.median(np.abs(x[i1:i2] - med)) + 1e-12
            if np.abs(x[i]-med) > t0*mad:
                y[i] = med
        return y

    def _denoise_light(self, y, win=11, order=2, sigma=1.0):
        y = np.asarray(y, float); n = y.size
        if n < 5: return y.copy()
        win = min(max(5, win), n-1); 
        if win % 2 == 0: win -= 1
        sm = savgol_filter(y, window_length=win, polyorder=min(order, win-1), mode='interp')
        return gaussian_filter1d(sm, sigma=max(0.6, sigma))

    def _detrend_light(self, w, y, win=41, poly=3):
        y = np.asarray(y, float); n = y.size
        if n < 7: return y - np.median(y)
        win = min(max(7, win), n-1)
        if win % 2 == 0: win -= 1
        trend = savgol_filter(y, window_length=win, polyorder=min(poly, win-1), mode='interp')
        return y - trend

    def _find_bandwidth_points(self, wl, y, idx, peak_h, baseline):
        half = (peak_h - baseline)/2 + baseline
        i = idx
        while i > 0 and y[i] > half: i -= 1
        if i < idx and y[i] <= half:
            x1,y1 = wl[i], y[i]; x2,y2 = wl[i+1], y[i+1]
            L = x1 + (half - y1) * (x2 - x1) / (y2 - y1) if y2 != y1 else x1
        else:
            L = wl[idx] - 0.15
        j = idx; n = len(y)-1
        while j < n and y[j] > half: j += 1
        if j > idx and y[j] <= half:
            x1,y1 = wl[j-1], y[j-1]; x2,y2 = wl[j], y[j]
            R = x1 + (half - y1) * (x2 - x1) / (y2 - y1) if y2 != y1 else x2
        else:
            R = wl[idx] + 0.15
        return L, R

    def _find_main_peak_bandwidth(self, wl, y):
        baseline = np.percentile(y, 5)
        adj = y - baseline
        peaks, props = find_peaks(adj, distance=20, prominence=0.1, height=0.05, width=2)
        if not peaks.size: return None
        idx = peaks[np.argmax(props['prominences'] if 'prominences' in props else props['peak_heights'])]
        L, R = self._find_bandwidth_points(wl, y, idx, y[idx], baseline)
        return L, R

    def _mask_acf(self, y, m, max_lag_pts, smooth_win=7):
        y = np.asarray(y, float); m = np.asarray(m, bool)
        if y.size < 4 or np.count_nonzero(m) < 4: return None
        mu = np.mean(y[m]); y0 = y - mu
        denom0 = np.sum(y0[m]*y0[m]); 
        if denom0 <= 0: return None
        acf = np.zeros(max_lag_pts+1, float)
        for k in range(0, max_lag_pts+1):
            pair = m if k == 0 else (m[:-k] & m[k:])
            if np.count_nonzero(pair) < 3: 
                acf[k] = 0; continue
            if k == 0:
                num = np.sum(y0[m]*y0[m]); den = denom0
            else:
                num = np.sum(y0[:-k][pair] * y0[k:][pair])
                den = np.sqrt(np.sum(y0[:-k][pair]**2) * np.sum(y0[k:][pair]**2))
            acf[k] = num/den if den > 0 else 0
        if smooth_win > 3:
            win = min(smooth_win, (len(acf)//2)*2+1)
            if win % 2 == 0: win -= 1
            acf = savgol_filter(acf, win, 2)
        acf = (acf - np.min(acf))
        if np.max(acf) > 0: acf = acf / np.max(acf)
        return acf

    def _refine_quad(self, x1, x0, x2, y1, y0, y2):
        den = (y1 - 2*y0 + y2)
        if den == 0: return x0
        delta = 0.5 * (y1 - y2) / den
        return x0 + delta * (x2 - x1) / 2.0

    def _fpi_period_via_acf(self, wl, y):
        # 预处理（轻量）
        y1 = self._hampel(y, 9, 3.0)
        y1 = self._denoise_light(y1, win=11, order=2, sigma=1.0)
        y1 = self._detrend_light(wl, y1, win=41, poly=3)

        dx = float(np.median(np.diff(wl)))
        if dx <= 0: return None
        lag_min = max(1, int(np.floor(FPI_MIN_PERIOD / dx)))
        lag_max = max(lag_min+2, int(np.ceil(FPI_MAX_PERIOD / dx)))
        if lag_max >= y1.size - 2:
            lag_max = y1.size - 3
        if lag_max <= lag_min + 2:
            return None

        # FBG 带宽掩蔽
        pk = self._find_main_peak_bandwidth(wl, self._denoise_light(y, win=11, order=2, sigma=1.0))
        if pk is None: return None
        L, R = pk
        valid_mask = (wl < L) | (wl > R)

        acf = self._mask_acf(y1, valid_mask, lag_max, smooth_win=7)
        if acf is None: return None

        seg = acf[lag_min:lag_max+1]
        k_rel = int(np.argmax(seg))
        k0 = lag_min + k_rel
        if k0-1 < 0 or k0+1 >= len(acf): return None

        k_star = self._refine_quad(k0-1, k0, k0+1, acf[k0-1], acf[k0], acf[k0+1])
        T = float(k_star) * dx
        if not (FPI_MIN_PERIOD*0.8 <= T <= FPI_MAX_PERIOD*1.2):
            return None
        return T
