# ui.py
import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QGroupBox, QComboBox, QPushButton, QLabel, QLineEdit, QCheckBox, QTextEdit,
    QSplitter, QSizePolicy, QToolBar, QAction, QFrame, QScrollArea
)
from PyQt5.QtCore import Qt, QSize   # <-- 关键：引入 QSize
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavToolbar
from matplotlib.figure import Figure
import matplotlib.font_manager as fm


class GM8050ControlAppUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('GM8050 光谱解调仪控制软件')
        self.resize(1280, 900)

        self.setStyleSheet("""
            QMainWindow { background: #FAFBFD; }
            QGroupBox {
                background: #FFFFFF;
                border: 1px solid #E6E9F2;
                border-radius: 10px;
                margin-top: 12px;
            }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0px 4px; }
            QPushButton {
                background: #2F7AF8; color: #fff; border: none; border-radius: 8px;
                padding: 8px 12px;
            }
            QPushButton:disabled { background: #BFD0F9; color: #f6f6f6; }
            QPushButton#secondary { background: #EEF3FF; color: #1F3A93; }
            QLabel { color: #333; }
            QLineEdit, QComboBox, QTextEdit {
                background: #FFFFFF; border: 1px solid #E6E9F2; border-radius: 6px;
            }
            QToolBar { background: #FFFFFF; border-bottom: 1px solid #E6E9F2; padding: 4px; }
        """)

        # ---------------- 顶部工具栏（用 QAction 触发对应按钮） ----------------
        toolbar = QToolBar("主工具栏")
        toolbar.setIconSize(QSize(18, 18))        # <-- 修正：使用 QSize
        self.addToolBar(Qt.TopToolBarArea, toolbar)

        # 先创建“真正的按钮”（function.py 会直接绑定这些按钮）
        self.refresh_btn = QPushButton("刷新串口"); self.refresh_btn.setObjectName("secondary")
        self.connect_btn = QPushButton("连接设备")
        self.disconnect_btn = QPushButton("断开"); self.disconnect_btn.setEnabled(False)

        self.start_demod_btn = QPushButton("启动解调")
        self.stop_demod_btn = QPushButton("停止解调")
        self.read_spectrum_btn = QPushButton("读取光谱数据")
        self.save_data_btn = QPushButton("保存当前光谱数据")
        self.realtime_decode_btn = QPushButton("实时解读")

        # 用 QAction 映射到这些按钮的 click()，避免重复放置同一控件
        def add_action(text, target_btn):
            act = QAction(text, self)
            act.triggered.connect(target_btn.click)
            toolbar.addAction(act)

        add_action("刷新串口", self.refresh_btn)
        add_action("连接设备", self.connect_btn)
        add_action("断开", self.disconnect_btn)
        toolbar.addSeparator()
        add_action("启动解调", self.start_demod_btn)
        add_action("停止解调", self.stop_demod_btn)
        toolbar.addSeparator()
        add_action("读取光谱", self.read_spectrum_btn)
        add_action("保存当前光谱", self.save_data_btn)
        toolbar.addSeparator()
        add_action("实时解读", self.realtime_decode_btn)

        # ---------------- 中心区域：左侧控制 + 右侧绘图 ----------------
        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(10, 8, 10, 10)
        layout.setSpacing(10)

        splitter = QSplitter(Qt.Horizontal)
        layout.addWidget(splitter)

        # 左侧控制（可滚动）
        left_wrap = QWidget()
        left_layout = QVBoxLayout(left_wrap)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(10)

        # 串口设置
        com_group = QGroupBox("串口设置")
        com_grid = QGridLayout(com_group)
        self.port_combo = QComboBox()
        self.baudrate_edit = QLineEdit("115200")
        com_grid.addWidget(QLabel("串口号"), 0, 0); com_grid.addWidget(self.port_combo, 0, 1)
        com_grid.addWidget(QLabel("波特率"), 1, 0); com_grid.addWidget(self.baudrate_edit, 1, 1)
        com_btn_row = QHBoxLayout()
        # 这里再放一套“页面内按钮”（就是同一对象本身）
        for b in (self.refresh_btn, self.connect_btn, self.disconnect_btn):
            b.setMinimumHeight(32); b.setCursor(Qt.PointingHandCursor)
        com_btn_row.addWidget(self.refresh_btn)
        com_btn_row.addWidget(self.connect_btn)
        com_btn_row.addWidget(self.disconnect_btn)
        com_grid.addLayout(com_btn_row, 2, 0, 1, 2)

        # 激光控制
        laser_group = QGroupBox("激光控制")
        laser_row = QHBoxLayout(laser_group)
        self.laser_on_btn = QPushButton("开启激光")
        self.laser_off_btn = QPushButton("关闭激光"); self.laser_off_btn.setObjectName("secondary")
        self.laser_status_label = QLabel("状态: 未连接")
        for b in (self.laser_on_btn, self.laser_off_btn):
            b.setMinimumHeight(32); b.setCursor(Qt.PointingHandCursor)
        laser_row.addWidget(self.laser_on_btn)
        laser_row.addWidget(self.laser_off_btn)
        laser_row.addStretch(1)
        laser_row.addWidget(self.laser_status_label)

        # 光谱扫描参数
        spectrum_group = QGroupBox("光谱扫描参数")
        spec_row = QGridLayout(spectrum_group)
        self.start_wl_edit = QLineEdit("1540.000")
        self.stop_wl_edit = QLineEdit("1560.000")
        self.step_edit = QLineEdit("0.020")
        spec_row.addWidget(QLabel("起始波长 (nm)"), 0, 0); spec_row.addWidget(self.start_wl_edit, 0, 1)
        spec_row.addWidget(QLabel("终止波长 (nm)"), 1, 0); spec_row.addWidget(self.stop_wl_edit, 1, 1)

        # 通道选择
        channel_group = QGroupBox("通道选择")
        ch_row = QHBoxLayout(channel_group)
        self.ch1_check = QCheckBox("通道1"); self.ch1_check.setChecked(True)
        self.ch2_check = QCheckBox("通道2"); self.ch2_check.setChecked(True)
        self.ch3_check = QCheckBox("通道3"); self.ch3_check.setChecked(True)
        self.ch4_check = QCheckBox("通道4"); self.ch4_check.setChecked(True)
        ch_row.addWidget(self.ch1_check); ch_row.addWidget(self.ch2_check)
        ch_row.addWidget(self.ch3_check); ch_row.addWidget(self.ch4_check)
        ch_row.addStretch(1)

        # 解调/数据操作（页面内按钮）
        demod_group = QGroupBox("解调/数据")
        demod_row1 = QHBoxLayout(); demod_row2 = QHBoxLayout()
        demod_group.setLayout(QVBoxLayout())
        demod_group.layout().addLayout(demod_row1)
        demod_group.layout().addLayout(demod_row2)

        for b in (self.start_demod_btn, self.stop_demod_btn, self.read_spectrum_btn,
                  self.save_data_btn, self.realtime_decode_btn):
            b.setMinimumHeight(32); b.setCursor(Qt.PointingHandCursor)
        self.stop_demod_btn.setObjectName("secondary")
        self.realtime_decode_btn.setObjectName("secondary")

        demod_row1.addWidget(self.start_demod_btn)
        demod_row1.addWidget(self.stop_demod_btn)
        demod_row1.addWidget(self.realtime_decode_btn)
        demod_row2.addWidget(self.read_spectrum_btn)
        demod_row2.addWidget(self.save_data_btn)

        # 日志输出
        log_group = QGroupBox("消息/日志")
        log_layout = QVBoxLayout(log_group)
        self.output_text = QTextEdit(); self.output_text.setReadOnly(True)
        btns = QHBoxLayout()
        self._btn_clear_log = QPushButton("清空日志"); self._btn_clear_log.setObjectName("secondary")
        btns.addStretch(1); btns.addWidget(self._btn_clear_log)
        log_layout.addWidget(self.output_text); log_layout.addLayout(btns)

        for w in [com_group, laser_group, spectrum_group, channel_group, demod_group, log_group]:
            left_layout.addWidget(w)
        left_layout.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidget(left_wrap)
        scroll.setMinimumWidth(380)
        splitter.addWidget(scroll)

        # 右侧绘图
        right_wrap = QWidget()
        right_layout = QVBoxLayout(right_wrap)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)

        self.fig = Figure(figsize=(10, 8), constrained_layout=True)
        self.canvas = FigureCanvas(self.fig)
        self.nav_toolbar = NavToolbar(self.canvas, right_wrap)

        font_path = fm.findfont(fm.FontProperties(family='SimHei'))
        self.ax = self.fig.add_subplot(111)
        self.ax.set_title('光谱数据', fontproperties=fm.FontProperties(fname=font_path), pad=8)
        self.ax.set_xlabel('波长 (nm)', fontproperties=fm.FontProperties(fname=font_path))
        self.ax.set_ylabel('幅值', fontproperties=fm.FontProperties(fname=font_path))
        self.ax.grid(True, linestyle='--', linewidth=0.6, alpha=0.45)

        right_layout.addWidget(self.nav_toolbar)
        right_layout.addWidget(self.canvas)

        splitter.addWidget(right_wrap)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        self.statusBar().showMessage("准备就绪")

        self._btn_clear_log.clicked.connect(self.output_text.clear)

        # 与 function.py 兼容：提供同名方法
        self.set_controls_enabled(False)

    # 工具栏分隔线
    def _h_sep(self):
        line = QFrame()
        line.setFrameShape(QFrame.VLine)
        line.setStyleSheet("color: #E6E9F2;")
        return line

    # 兼容 function.py 的同名方法
    def set_controls_enabled(self, enabled: bool):
        self.laser_on_btn.setEnabled(enabled)
        self.laser_off_btn.setEnabled(enabled)
        self.start_demod_btn.setEnabled(enabled)
        self.stop_demod_btn.setEnabled(enabled)
        self.read_spectrum_btn.setEnabled(enabled)
        self.save_data_btn.setEnabled(enabled)
        self.ch1_check.setEnabled(enabled)
        self.ch2_check.setEnabled(enabled)
        self.ch3_check.setEnabled(enabled)
        self.ch4_check.setEnabled(enabled)
        self.realtime_decode_btn.setEnabled(enabled)
