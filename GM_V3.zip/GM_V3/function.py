import time
import os
import serial.tools.list_ports
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QFileDialog
import matplotlib.font_manager as fm
import numpy as np

from ui import GM8050ControlAppUI
from basic import GM8050Reader
from realtime import RealTimeDecodeWindow  # 实时解读窗口

from matplotlib import rcParams
rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
rcParams['axes.unicode_minus'] = False

class GM8050ControlApp(GM8050ControlAppUI):
    def __init__(self):
        super().__init__()
        self.reader = None
        self.refresh_ports()

        # 绑定信号
        self.refresh_btn.clicked.connect(self.refresh_ports)
        self.connect_btn.clicked.connect(self.connect_device)
        self.disconnect_btn.clicked.connect(self.disconnect_device)
        self.laser_on_btn.clicked.connect(self.laser_on)
        self.laser_off_btn.clicked.connect(self.laser_off)
        self.start_demod_btn.clicked.connect(self.start_demodulation)
        self.stop_demod_btn.clicked.connect(self.stop_demodulation)
        self.read_spectrum_btn.clicked.connect(self.read_spectrum_data)
        self.save_data_btn.clicked.connect(self.save_current_spectrum)
        self.realtime_decode_btn.clicked.connect(self.open_realtime_decode)

        # 缓存
        self.last_wavelengths = []
        self.last_spectrum = [[] for _ in range(4)]

        self.set_controls_enabled(False)

    # ---------- 公共 UI ----------
    def refresh_ports(self):
        self.port_combo.clear()
        ports = serial.tools.list_ports.comports()
        for p in ports:
            self.port_combo.addItem(p.device)
        self.log_message(f"找到 {len(ports)} 个可用串口" if ports else "未找到可用串口")

    def set_controls_enabled(self, enabled):
        self.laser_on_btn.setEnabled(enabled)
        self.laser_off_btn.setEnabled(enabled)
        self.start_demod_btn.setEnabled(enabled)
        self.stop_demod_btn.setEnabled(enabled)
        self.read_spectrum_btn.setEnabled(enabled)
        self.save_data_btn.setEnabled(enabled)
        self.ch1_check.setEnabled(enabled)
        self.ch2_check.setEnabled(enabled)
        self.ch3_check.setEnabled(enabled)
        self.ch4_check.setEnabled(enabled)
        self.realtime_decode_btn.setEnabled(enabled)

    def log_message(self, msg):
        self.output_text.append(msg)
        self.output_text.ensureCursorVisible()
        self.statusBar().showMessage(msg)

    # ---------- 连接/激光 ----------
    def connect_device(self):
        try:
            port = self.port_combo.currentText()
            if not port:
                self.log_message("错误: 请选择串口")
                return
            baudrate = int(self.baudrate_edit.text().strip() or "115200")
            self.log_message(f"正在连接串口 {port}，波特率 {baudrate}...")
            QApplication.processEvents()
            self.reader = GM8050Reader(port, baudrate)
            self.log_message("设备连接成功!")
            self.connect_btn.setEnabled(False)
            self.disconnect_btn.setEnabled(True)
            self.set_controls_enabled(True)
            self.laser_status_label.setText("状态: 未知 (请点击激光按钮)")
        except Exception as e:
            self.log_message(f"连接失败: {e}")

    def disconnect_device(self):
        if self.reader:
            try:
                self.reader.close()
                self.log_message("设备已断开连接")
            except:
                pass
            self.reader = None
        self.connect_btn.setEnabled(True)
        self.disconnect_btn.setEnabled(False)
        self.set_controls_enabled(False)
        self.laser_status_label.setText("状态: 未连接")

    def laser_on(self):
        if not self.reader:
            self.log_message("错误: 设备未连接")
            return
        try:
            self.reader.send_command("01", "06", self.reader.LASER_CTRL_REG + "0001")
            self.laser_status_label.setText("状态: 已开启")
            self.log_message("激光开启命令发送成功!")
        except Exception as e:
            self.log_message(f"开启激光失败: {e}")

    def laser_off(self):
        if not self.reader:
            self.log_message("错误: 设备未连接")
            return
        try:
            self.reader.send_command("01", "06", self.reader.LASER_CTRL_REG + "0000")
            self.laser_status_label.setText("状态: 已关闭")
            self.log_message("激光关闭命令发送成功!")
        except Exception as e:
            self.log_message(f"关闭激光失败: {e}")

    # ---------- 解调/光谱 ----------
    def start_demodulation(self):
        try:
            self.reader.start_demodulation()
            self.log_message("解调已成功启动")
        except Exception as e:
            self.log_message(f"启动解调失败: {e}")

    def stop_demodulation(self):
        try:
            self.reader.stop_demodulation()
            self.log_message("解调已成功停止")
        except Exception as e:
            self.log_message(f"停止解调失败: {e}")

    def read_spectrum_data(self):
        """触发扫描→读取光谱（使用设备默认步长），仅按用户波长范围筛选并绘制。"""
        try:
            if not self.reader:
                self.log_message("错误: 设备未连接")
                return [], []
            self.log_message("启动光谱扫描…")
            self.reader.start_spectrum_scan()

            wavelengths, spectrum = self.reader.read_spectrum()
            if not wavelengths or not any(len(ch) for ch in spectrum):
                self.log_message("错误: 未获取到光谱数据")
                return [], []

            # 仅按范围筛选，不再做“步长整倍数”处理
            try:
                user_start = float(self.start_wl_edit.text())
                user_stop = float(self.stop_wl_edit.text())
            except ValueError:
                self.log_message("错误: 无效的波长范围")
                return [], []

            w = np.asarray(wavelengths, dtype=float)
            mask = (w >= user_start) & (w <= user_stop)
            if not np.any(mask):
                self.log_message("错误: 没有在设定波长范围内的数据")
                return [], []

            filtered_wavelengths = w[mask].tolist()
            filtered_spectrum = []
            for ch in range(4):
                y = np.asarray(spectrum[ch], dtype=float)
                filtered_spectrum.append(y[mask].tolist())

            # 缓存“当前光谱”
            self.last_wavelengths = filtered_wavelengths
            self.last_spectrum = filtered_spectrum

            # 绘制
            self.plot_spectrum(filtered_wavelengths, filtered_spectrum)
            self.log_message(f"成功获取光谱数据: {len(filtered_wavelengths)} 点")
            return filtered_wavelengths, filtered_spectrum
        except Exception as e:
            self.log_message(f"读取失败: {e}")
            return [], []

    def plot_spectrum(self, wavelengths, spectrum):
        """紧凑坐标绘图，按勾选通道显示。"""
        self.ax.clear()
        font_path = fm.findfont(fm.FontProperties(family='SimHei'))
        font_prop = fm.FontProperties(fname=font_path)
        self.ax.set_title('光谱扫描结果', fontproperties=font_prop)
        self.ax.set_xlabel('波长 (nm)', fontproperties=font_prop)
        self.ax.set_ylabel('幅值', fontproperties=font_prop)
        self.ax.grid(True, linestyle='--', linewidth=0.6, alpha=0.45)

        colors = ['b', 'g', 'r', 'c']
        labels = ['通道 1', '通道 2', '通道 3', '通道 4']
        ys_for_scale = []

        for i in range(4):
            enabled = (i == 0 and self.ch1_check.isChecked()) or \
                      (i == 1 and self.ch2_check.isChecked()) or \
                      (i == 2 and self.ch3_check.isChecked()) or \
                      (i == 3 and self.ch4_check.isChecked())
            if not enabled or not spectrum[i]:
                continue
            y = np.asarray(spectrum[i], dtype=float)
            self.ax.plot(wavelengths, y, colors[i], linewidth=1.5, label=labels[i], alpha=0.95)
            ys_for_scale.append(y)

        # 紧凑坐标
        if len(wavelengths) >= 2:
            xmin, xmax = float(min(wavelengths)), float(max(wavelengths))
            xspan = max(xmax - xmin, 1e-9)
            self.ax.set_xlim(xmin - xspan * 0.02, xmax + xspan * 0.02)
        if ys_for_scale:
            all_y = np.concatenate(ys_for_scale)
            y_min, y_max = float(np.min(all_y)), float(np.max(all_y))
            y_span = max(y_max - y_min, 1e-9)
            self.ax.set_ylim(y_min - y_span * 0.05, y_max + y_span * 0.05)

        self.ax.legend(prop=font_prop, frameon=False)
        self.canvas.draw_idle()

    # ---------- 保存当前光谱 ----------
    def save_current_spectrum(self):
        if not self.last_wavelengths or not any(self.last_spectrum):
            self.log_message("没有可保存的光谱数据，请先读取光谱")
            return
        path, _ = QFileDialog.getSaveFileName(self, "保存当前光谱数据", "spectrum.csv", "CSV Files (*.csv)")
        if not path:
            return
        try:
            import csv
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["wavelength_nm", "ch1", "ch2", "ch3", "ch4"])
                for i, wl in enumerate(self.last_wavelengths):
                    row = [wl]
                    for ch in range(4):
                        v = self.last_spectrum[ch][i] if i < len(self.last_spectrum[ch]) else ""
                        row.append(v)
                    writer.writerow(row)
            self.log_message(f"已保存: {path}")
        except Exception as e:
            self.log_message(f"保存失败: {e}")

    # ---------- 实时解读 ----------
    def open_realtime_decode(self):
        if not self.reader:
            self.log_message("错误: 设备未连接")
            return
        try:
            start_nm = float(self.start_wl_edit.text())
            stop_nm = float(self.stop_wl_edit.text())
        except ValueError:
            self.log_message("错误: 无效的波长范围")
            return

        # 单实例
        if hasattr(self, "rt_window") and self.rt_window:
            try:
                self.rt_window.activateWindow()
                self.rt_window.raise_()
                return
            except Exception:
                self.rt_window = None

        self.rt_window = RealTimeDecodeWindow(self.reader, (start_nm, stop_nm))
        self.rt_window.setAttribute(Qt.WA_DeleteOnClose, True)

        def _on_closed(*_):
            self.rt_window = None
            self.log_message("实时解读窗口已关闭")
        self.rt_window.destroyed.connect(_on_closed)

        self.rt_window.show()
        self.log_message("已打开实时解读窗口（多通道）")
