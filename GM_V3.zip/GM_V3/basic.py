# -*- coding: utf-8 -*-
import serial, time, struct, threading
import numpy as np
from typing import List, Tuple, Optional

class GM8050Reader:
    LASER_CTRL_REG = "0200"
    DEMOD_CTRL_REG = "0201"
    SINGLE_SCAN_REG = "0202"
    CENTER_WL_FLOAT_BASE = "0300"
    SPECTRUM_BASE = "2000"
    NUM_CHANNELS = 4
    MAX_BURST_14 = 2200  # 14H 单次连续寄存器上限

    def __init__(self, port: str, baudrate: int = 115200, timeout: float = 1.0):
        self.ser = serial.Serial(
            port=port, baudrate=baudrate, bytesize=8,
            parity=serial.PARITY_NONE, stopbits=1, timeout=timeout
        )
        self._rx = bytearray()
        self._io_lock = threading.RLock()   # ★ 多线程串口互斥
        self._scan_params: Optional[Tuple[float, float, float]] = None
        self._wavelengths: Optional[np.ndarray] = None

    # ---------- CRC / 构帧 ----------
    @staticmethod
    def calc_crc16(data: bytes) -> int:
        crc = 0xFFFF
        for b in data:
            crc ^= b
            for _ in range(8):
                crc = (crc >> 1) ^ 0xA001 if (crc & 1) else (crc >> 1)
        return crc & 0xFFFF

    def _pkt(self, addr_hex: str, func_hex: str, data_hex: str = "") -> bytes:
        body = bytes.fromhex(addr_hex + func_hex + data_hex)
        c = self.calc_crc16(body)
        return body + bytes([c & 0xFF, (c >> 8) & 0xFF])

    def _send_unlocked(self, addr_hex: str, func_hex: str, data_hex: str = "") -> bool:
        try:
            self.ser.write(self._pkt(addr_hex, func_hex, data_hex))
            return True
        except Exception as e:
            print(f"发送错误: {e}")
            return False

    def _recv_unlocked(self, expect_len: int, timeout: float = 1.2) -> str:
        """
        读取到 >= expect_len 或超时；不 reset_input_buffer，避免多线程丢包。
        """
        self._rx = bytearray()
        t0 = time.time(); last = t0
        while time.time() - t0 < timeout:
            n = self.ser.in_waiting
            if n:
                self._rx.extend(self.ser.read(n))
                last = time.time()
                # 异常功能码
                if len(self._rx) >= 3 and (self._rx[1] & 0x80):
                    if len(self._rx) >= 5:
                        err = self._rx[2]
                        return {1:"非法功能码",2:"非法数据地址",3:"非法数据值"}.get(err, f"未知错误:{err}")
                if len(self._rx) >= expect_len:
                    return "成功"
            if (time.time() - last > 0.12) and len(self._rx) < 5:
                return "无数据"
        return "响应超时"

    def _transact(self, addr_hex: str, func_hex: str, data_hex: str,
                  expect_len: int, timeout: float = 1.2) -> bool:
        """
        ★ 原子事务：写 + 读，串口加锁，防止写/读交叉
        """
        with self._io_lock:
            if not self._send_unlocked(addr_hex, func_hex, data_hex):
                return False
            return self._recv_unlocked(expect_len, timeout) == "成功"

    def send_command(self, addr_hex: str, func_hex: str, data_hex: str,
                     expect_len: int = None, timeout: float = 0.5) -> bool:

        # 自动估计回包长度（按协议）
        # 06H：写单寄存器，固定 8B 回包
        # 03H：读寄存器，回包=addr(1)+func(1)+bytecnt(1)+N*2+CRC(2)
        # 14H：读寄存器(最大2200)，回包=addr(1)+func(1)+bytecnt(2)+N*2+CRC(2)
        if expect_len is None:
            if func_hex == "06":
                expect = 8
            elif func_hex == "03":
                cnt = int(data_hex[4:8], 16) if len(data_hex) >= 8 else 1
                expect = 1 + 1 + 1 + 2 * cnt + 2
            elif func_hex == "14":
                cnt = int(data_hex[4:8], 16) if len(data_hex) >= 8 else 1
                expect = 1 + 1 + 2 + 2 * cnt + 2
            else:
                expect = 8
        else:
            expect = int(expect_len)

        ok = self._transact(addr_hex, func_hex, data_hex, expect, timeout)
        if not ok:
            raise RuntimeError("设备未响应/超时")
        return True

    # ---------- 控制 ----------
    def start_demodulation(self):
        self._transact("01", "06", f"{self.DEMOD_CTRL_REG}0001", 8, 0.3)

    def stop_demodulation(self):
        self._transact("01", "06", f"{self.DEMOD_CTRL_REG}0000", 8, 0.3)

    def start_spectrum_scan(self):
        """
        启动单次扫描：写 06H 并把回包读掉（8字节）。
        不再固定 sleep，最小化占用；由外部 0.5s 定时调度。
        """
        self._transact("01", "06", f"{self.SINGLE_SCAN_REG}0001", 8, 0.25)

    # ---------- 扫描参数（按当前程序习惯：每次读取） ----------
    def _read_u16_by_03(self, reg_hex: str) -> Optional[int]:
        if self._transact("01", "03", f"{reg_hex}0001", 7, 1.0):
            return (self._rx[3] << 8) | self._rx[4]
        return None

    def read_scan_parameters(self) -> tuple:
        """
        1005/1006/1007：起点/终点/步长（0.001nm）
        这里不做缓存，尽量保持你当前程序的行为；线程安全由 _transact 保证。
        """
        try:
            v_start = self._read_u16_by_03("1005")
            v_stop  = self._read_u16_by_03("1006")
            v_step  = self._read_u16_by_03("1007")
            if v_start is None or v_stop is None or v_step is None or v_step <= 0:
                return (0, 0, 0)
            start_wl = 1520.0 + v_start / 1000.0
            stop_wl  = 1520.0 + v_stop  / 1000.0
            step_wl  =           v_step / 1000.0
            return (start_wl, stop_wl, step_wl)
        except Exception as e:
            print(f"读取扫描参数失败: {e}")
            return (0, 0, 0)

    # ---------- 14H 分块读取 ----------
    def _read_14_block(self, base_addr: int, count: int, timeout: float = 1.5) -> Optional[np.ndarray]:
        a_hi, a_lo = (base_addr >> 8) & 0xFF, base_addr & 0xFF
        c_hi, c_lo = (count >> 8) & 0xFF, count & 0xFF
        data_hex = f"{a_hi:02X}{a_lo:02X}{c_hi:02X}{c_lo:02X}"
        expect = 1 + 1 + 2 + 2 * count + 2  # addr+func+bytecnt+data+CRC
        if not self._transact("01", "14", data_hex, expect, timeout):
            return None
        byte_count = (self._rx[2] << 8) | self._rx[3]
        raw = self._rx[4:4 + byte_count]
        if len(raw) < 2:
            return None
        return np.frombuffer(memoryview(raw), dtype=">u2")

    # ---------- 光谱读取（向量化，4通道） ----------
    def read_spectrum(self) -> tuple:
        """
        读取光谱：每通道 2051 点（<=2200，可一次 14H），线程安全。
        """
        try:
            start_wl, stop_wl, step_wl = self.read_scan_parameters()
            if step_wl <= 0:
                print("无效的扫描步长")
                return [], []

            num_points = 2051
            wavelengths = [start_wl + i * step_wl for i in range(num_points)]

            base = [0x2000, 0x3000, 0x4000, 0x5000]
            spectra = []
            for ch in range(self.NUM_CHANNELS):
                arr = self._read_14_block(base[ch], num_points, timeout=1.3)
                if arr is None or arr.size == 0:
                    print(f"通道{ch+1}光谱读取失败")
                    spectra.append([])
                    continue
                if arr.size < num_points:
                    pad = np.zeros(num_points - arr.size, dtype=arr.dtype)
                    arr = np.concatenate([arr, pad])
                spectra.append(arr.astype(np.uint16).tolist())

            return wavelengths, spectra
        except Exception as e:
            print(f"读取光谱数据失败: {e}")
            return [], []

    def close(self):
        if self.ser and self.ser.is_open:
            self.ser.close()
